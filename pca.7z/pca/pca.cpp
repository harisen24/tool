#include "pca.h"

pca::pca(void)
{
  m_data_counter = 0;
}

pca::~pca(void)
{
}

void pca::setDimension(int d)
{
  m_dimension = d;
  
  //���U�����U�s��̑傫����ݒ�
  this->m_V.resize(m_dimension,m_dimension);

  //���ϒl�̑傫����ݒ�
  this->m_average.resize(m_dimension);

  //��^���̑傫����ݒ�
  this->m_contributing_rate.resize(m_dimension);

  for(int i = 0;i < (int)m_average.size();i++)
  {
    m_average[i] = 0;
  }
  
  return ;
}

void pca::setPcaData(pca_data pd)
{
  if(pd.data.size() != m_dimension)
  {
    std::cout <<"error m_dimension is "<<m_dimension<<" but pd size is" << pd.data.size()<<"!"<<std::endl;
    return ;
  }

  //�v�f�̑}��
  m_PcaData.push_back(pd); 
  m_originaldata.resize(m_data_counter+1,m_dimension);

  
  for(int i = 0;i < (int)m_average.size();i++)
  {
    m_average[i] = 0;
  }

  //���ϒl�Z�o
  for(int j = 0;j < (int)m_dimension;j++){
    for(int i = 0;i < (int)m_PcaData.size();i++)
    {
      m_average[j] += m_PcaData[i].data[j];
      m_originaldata(i,j) = m_PcaData[i].data[j];
    }
    m_average[j] /= (double)m_PcaData.size();
  }
  m_data_counter++;

  return ;
}

CPPL::dgematrix pca::CreateCovarianceMatrix()
{
  m_V.resize(m_dimension,m_dimension);

  for(int i = 0;i < this->m_dimension;i++){
    for(int j = 0;j < this->m_dimension;j++){ //m_V(0,1) m_V(0,2)�E�E�Em_V(0,j)
      
      //������
      m_V(i,j) = 0.0;

      if(i == j)//�Ίp�v�f�Ȃ番�U
      {
        m_V(i,j) = m_variance(m_average[i],m_PcaData,i);
      }
      else//����ȊO�Ȃ狤���U
      {
        m_V(i,j) = m_covariance(m_average[i],m_average[j],m_PcaData,i,j);
      }
    }
  }
  CPPL::dgematrix tmp = m_V;
  CPPL::dgematrix aa;

  //�ŗL�l�E�ŗL�x�N�g���v�Z
  tmp.dgeev(lambda_r,lambda_i,ur,ui);
  //tmp.dggev(aa,lambda_r,lambda_i);
  //std::cout << "aaa"<<aa<<std::endl;
  BubSort(&lambda_r,&ur);

  //��^�����v�Z
  for(int i = 0;i < m_dimension;i++)
  {
    m_contributing_rate[i] = this->lambda_r[i];
    double lambda = 0.0;
    for(int j = 0;j < m_dimension;j++)
    {
      lambda += this->lambda_r[j];
    }
    m_contributing_rate[i] /= lambda;
  }

  m_u.resize(m_dimension,m_dimension);
  for(int i = 0;i < (int)ur.size();i++)
  {
    double d = 0.0;
    for(int j = 0;j < m_dimension;j++)
      d += ur[i].array[j]*ur[i].array[j];

    ur[i] /= sqrt(d);//�P�ʌŗL�x�N�g����
  }  
  
  for(int i = 0;i < (int)ur.size();i++)
  {
    double d = 0.0;
    for(int j = 0;j < m_dimension;j++)
      m_u(j,i) = ur[i].array[j];
  }

  return m_V;
}


double pca::m_variance(double average,std::vector<pca_data> data,int data_number)
{
  double m_v = 0.0;
  for(int i = 0;i < (int)data.size();i++)
  {
    m_v += (data[i].data[data_number] - average)*(data[i].data[data_number] - average);
  }
  m_v /= (double)data.size();

  return m_v;
}

double pca::m_covariance(double average1,double average2,std::vector<pca_data> data,int data_number1,int data_number2)
{
  double m_c = 0.0; 
  
  for(int i = 0;i < (int)data.size();i++)
  {
    m_c += (data[i].data[data_number1] - average1)*(data[i].data[data_number2] - average2);
  }
  m_c /= (double)data.size();

  return m_c;
}
bool pca::read_pcaCSV(std::string filename)
{
  FILE *fp;
  char buf[256],buf2[256];
  std::vector<std::string> label;
  
  if((fp = fopen(filename.c_str(),"r")) == NULL)
    return false;

  fscanf(fp,"%s\n",buf);

  //pca��csv���ǂ����m�F
  int kk=0;
  while(buf[kk] != ',' && buf[kk] != '\n' )
  {
    buf2[kk] = buf[kk];
    kk++;
  }
  buf2[kk] = '\0';

  if(strcmp(buf2, "pca_csv")!=0)
  {
    fclose(fp);
    return false;
  }
  std::string origin_str(buf);
  kk = (int)origin_str.find(",");
  origin_str.replace(0,kk+1,"");
    
  
  //�������ǂݍ���
  kk=0;
  while(origin_str[kk] != ',' && origin_str[kk] != '\n' )
  {
    buf2[kk] = origin_str[kk];
    kk++;
  }
  buf2[kk] = '\0';
  m_dimension = atoi(buf2);
  this->setDimension(m_dimension);

  for(int i = 0;i < m_dimension+1;i++)
  {
    char c = fgetc(fp);
    int k=0;
    while(c != ',' && c != '\n' )
    {
      buf[k] = c;k++;
      c = fgetc(fp);
    }
    buf[k] = '\0';

    if(strcmp(buf,"label")==0)
      continue;
    label.push_back(std::string(buf));
  }

  int counter = 0;
  pca_data pd;
  pd.data.resize(m_dimension);


  while(fgets(buf,256,fp) != NULL)
  {
    std::string sbuf(buf);
    for(int i = 0;i < m_dimension + 1;i++)
    {
      if(i == 0)
      {
        char i_buf[256];    
        int k=0;
        while(sbuf[k] != ',')
        {
          i_buf[k] = sbuf[k];
          k++;
        }
        i_buf[k] = '\0';
        pd.label = std::string(i_buf);
      }
      else if(i == m_dimension )
      {
        sscanf(sbuf.c_str(),"%lf\n",&(pd.data[i-1]));
        break;
      }
      else
        sscanf_s(sbuf.c_str(),"%lf,",&(pd.data[i-1]));
      int c = (int)sbuf.find(",");
      sbuf.replace(0,c+1,"");
    }
    this->setPcaData(pd);
  }

  fclose(fp);

  //���U�����U�s��쐬
  this->CreateCovarianceMatrix();
  m_label = label;
  return true;
}

double pca::getContributingRate(int PrincipalNumber)
{
  return m_contributing_rate[PrincipalNumber];
}

double pca::getPrincipalScore(int LabelNumber,int PrincipalNumber)
{
  double score = 0.0;
  for(int i = 0; i < m_dimension; i++)
  {
    score += ur[PrincipalNumber].array[i]*( m_PcaData[LabelNumber].data[i] - m_average[i]);
  }
  return score;
}

void pca::BubSort(std::vector<double> *target,std::vector<CPPL::dcovector> *t2)
{
    double temp;
    CPPL::dcovector temp2;

    for (int i = 0; i < (int)target->size() - 1; i++) {
        for (int j = (int)target->size() - 1; j > i; j--) {
            if ((*target)[j - 1] < (*target)[j]) {  /* �O�̗v�f�̕����傫�������� */
                temp = (*target)[j];        /* �������� */
                temp2 = (*t2)[j];
                (*target)[j] = (*target)[j - 1];
                (*t2)[j] = (*t2)[j-1];
                (*target)[j - 1]= temp;
                (*t2)[j-1]=temp2;
            }
        }	
    }

    return ;
}
void pca::BubSort(std::vector<double> *target,std::vector<CPPL::drovector> *t2)
{
    double temp;
    CPPL::drovector temp2;

    for (int i = 0; i < (int)target->size() - 1; i++) {
        for (int j = (int)target->size() - 1; j > i; j--) {
            if ((*target)[j - 1] < (*target)[j]) {  /* �O�̗v�f�̕����傫�������� */
                temp = (*target)[j];        /* �������� */
                temp2 = (*t2)[j];
                (*target)[j] = (*target)[j - 1];
                (*t2)[j] = (*t2)[j-1];
                (*target)[j - 1]= temp;
                (*t2)[j-1]=temp2;
            }
        }	
    }

    return ;
}


bool pca::outPrincipalScoreCSV(std::ofstream *ofs)
{
  if(!ofs)
    return false;
  *ofs <<"���x��,";
  for(int i = 0;i<getDimension();i++)
    *ofs << "��"<<i+1<<"�听��,";
  *ofs <<"\n";
  for(int i = 0;i < getDataQuantity();i++ )
  {
    *ofs <<getPcaData(i).label<<",";
    for(int j = 0; j < getDimension();j++)
    {
      *ofs << getPrincipalScore(i,j)<<",";
    }
    *ofs << std::endl;
  }
  return true;
}

bool pca::outContributingRateCSV(std::ofstream *ofs)
{
  if(!ofs)
    return false;
  *ofs <<"��^��,";

  for(int j = 0; j < getDimension();j++)
  {
    *ofs << getContributingRate(j)<<",";
  }
  *ofs << std::endl;

  return true;
}

