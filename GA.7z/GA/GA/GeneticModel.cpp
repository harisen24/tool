#include "GeneticModel.h"
#define DEBUG

GeneticModel::GeneticModel(GAType ga , EVType ev , FILE *fp)
{
  setGAtype(ga);
  setEVtype(ev);
  fscanf(fp,"%d\n",&NumOfPkg);  
  N = NumOfPkg;
  int i ;

  if(GAT == GA_NORMAL)
  {
	fscanf(fp,"%d\n",&CapacityOfBag);
	fscanf(fp,"%d\n",&CapacityOfBag2);
	ValueOfPkg  = (int *)calloc(NumOfPkg,sizeof(int));
    WeightOfPkg = (int *)calloc(NumOfPkg,sizeof(int));
	for(i = 0 ; i < NumOfPkg;i++){
		fscanf(fp,"%d",&ValueOfPkg[i]);
#ifdef DEBUG
		printf("ValueOfPkg[%d]:%d \n",i,ValueOfPkg[i]);
#endif
	}
	  
	for(i = 0 ; i < NumOfPkg;i++){
	   fscanf(fp,"%d",&WeightOfPkg[i]);
#ifdef DEBUG
		printf("WaightOfPkg[%d]:%d \n",i,WeightOfPkg[i]);
#endif
	}
  }
  else if(GAT == WEIGHT_PLUS)
  {
	  fscanf(fp,"%d\n",&CapacityOfBag);
      ValueOfPkg  = (int *)calloc(NumOfPkg,sizeof(int));
      WeightOfPkg = (int *)calloc(NumOfPkg,sizeof(int));
	  SizeOfPkg   = (int *)calloc(NumOfPkg,sizeof(int));
	  for(i = 0 ; i < NumOfPkg; i++)
	  {
		  fscanf(fp,"%d",&ValueOfPkg[i]);
#ifdef DEBUG
		printf("ValueOfPkg[%d]:%d \n",i,ValueOfPkg[i]);
#endif
	  }
 	  for(i = 0 ; i < NumOfPkg;i++)
	  {
	      fscanf(fp,"%d",&WeightOfPkg[i]);
#ifdef DEBUG
		  printf("WaightOfPkg[%d]:%d \n",i,WeightOfPkg[i]);
#endif
	  }
	  for(i = 0 ; i < NumOfPkg;i++)
	  {
		  fscanf(fp,"%d",&SizeOfPkg[i]);
#ifdef DEBUG
		  printf("SizeOfPkg[%d]:%d \n",i,SizeOfPkg[i]);
#endif
	  }
  }
  else if(GAT == NAP2)
  {

  }
}


GeneticModel::~GeneticModel()
{
	/*
	if(ValueOfPkg != NULL)
	    free(ValueOfPkg);
	if(WeightOfPkg != NULL)
		free(WeightOfPkg);
	if(SizeOfPkg != NULL)
		free(SizeOfPkg);
*/

}	


bool GeneticModel::setGAtype(GAType ga)
{
	GAT = ga;
	return true;
}
bool GeneticModel::setEVtype(EVType ev)
{
	EVT = ev;
	return true;
}

genotype *GeneticModel::getIndividual()
{
	return individual;
}

genotype *GeneticModel::getIndividual(int i)
{
	return &individual[i];
}

// �̂̓K���x�v�Z
void GeneticModel::evaluation(int n) {
  int i,j;   // ��`�q���C���f�b�N�X
  int SumWeight = 0, SumValue = 0;
  double g = 0;//�K���x �y�i���e�B�[�@
  double alpha = 10.0;
  double ValuePerWeight[1000];
  int index[1000] = {0};
  int WeightCounter = 0;
  int *a = individual[n].gene;


  for(j = 0; j < N ;j++)
	  SumWeight += WeightOfPkg[j]*a[j];

  for(j = 0; j < N ;j++)
	  SumValue += ValueOfPkg[j]*a[j];

  switch(EVT)
  {
      case EV_NORMAL:
          g = SumValue - alpha*max(0,SumWeight - CapacityOfBag );

		  break;
	  case YOKUBARI:

		  for(i = 0 ; i < N ;i++)
		  {
			  ValuePerWeight[i] = ( (double)ValueOfPkg[i] / (double)WeightOfPkg[i] ) * (double)a[i];
			  index[i] = i;
		  }
		  bubbleSort(ValuePerWeight,index,N);

		  for(j = 0; j < N ; j++)
		  {
			  WeightCounter += WeightOfPkg[index[j]] * a[index[j]];

			  if( WeightCounter > CapacityOfBag )
				  a[index[j]] = 0;
			  else if( a[index[j]] == 1 )
				  g += ValueOfPkg[index[j]];
		  }
		  break;
  }
  individual[n].fitness = g;
}   // End of evaluation()

void GeneticModel::bubbleSort(double numbers[],int index[], int array_size)
{
  int i, j,iTemp;
  double temp;

  for (i = 0; i < (array_size - 1); i++) {
    for (j = (array_size - 1); j > i; j--) {
      if (numbers[j-1] > numbers[j]) {

        temp = numbers[j-1];
		iTemp = index[j-1];

        numbers[j-1] = numbers[j];
		index[j-1] = index[j];

        numbers[j] = temp;
		index[j] = iTemp;

      }
    }
  }

  return ;
}


// ��_����
void GeneticModel::one_point_crossover() {
  int i, ia, ib;   // �̃C���f�b�N�X
  int j;   // ��`�q���C���f�b�N�X
  int c;   // �����_
  int test[M];   // �̗̂��p�t���O
  int *temp;   // ��`�q�����ւ��邽�߂̉��ϐ�
  int r;   // �����l
  
  for(i=0; i<M; i++) test[i] = 0;

  temp = (int *)calloc(N,sizeof(int));

  ia = ib = 0;
  for(i=0; i<M/2; i++) 
  {
    // �̂������_���Ƀy�A�����O
    for(; test[ia]==1; ia=(ia+1)%M);
    test[ia] = 1;
    r = rand() % (M-2*i) + 1;

    while(r>0) {
      ib=(ib+1)%M;
      for(; test[ib]==1; ib=(ib+1)%M);
      r--;
    }
    test[ib] = 1;
    // ��ia��ib������
    if(flip((double)Pc)) 
	{
      c = rand() % N;
      for(j=0; j<c; j++) 
	  {
	    //�G���[�g�ۑ��헪
        if(individual[ia].bElite || individual[ib].bElite)
	      continue;
        temp[j] = individual[ia].gene[j];
        individual[ia].gene[j] = individual[ib].gene[j];
        individual[ib].gene[j] = temp[j];
      }
    }
  }
  free(temp);
}   // End of one_point_crossover()



// �ˑR�ψ�
void GeneticModel::mutation() {
  int i;   // �̃C���f�b�N�X
  int j;   // ��`�q���C���f�b�N�X
  
  for(i=0; i<M; i++)
    for(j=0; j<N; j++)
  	  if(flip((double)Pm) && !individual[i].bElite) {
        individual[i].gene[j] = (individual[i].gene[j] + 1) % 2;
      }
  
}   // End of mutation()



// ���[���b�g�I��
void GeneticModel::roulette_selection() {
  int h, i;   // �̃C���f�b�N�X
  double total_fitness;   // �K���x�̍��v�l
  double dart;   // ��
  double wheel;  // ���[���b�g�E�z�C�[��
  genotype ind_new[M];   // �I�𑀍��̌̏W��
  
  // �K���x�̍��v�l���v�Z
  total_fitness = 0;
  for(i=0; i<M; i++) total_fitness += individual[i].fitness;

  // ���[���b�g�E�z�C�[���ɏ]���Ď����������
  for(i=0; i<M; i++) {
    dart = (double)rand() / RAND_MAX;
    h = 0;
    wheel = individual[h].fitness / total_fitness;
    while(dart > wheel) {
      h++;
      wheel += individual[h].fitness / total_fitness;
    }
    ind_new[i] = individual[h];

	//�G���[�g�ۑ��헪
	if(individual[i].bElite)
		ind_new[i] = individual[i];
  }

  // �̏W���̍X�V
  for(i=0; i<M; i++) {
    individual[i] = ind_new[i];
  }

}   // End of roulette_selection()


// �̂̒��g��K���x�l����ʂɏo��
void GeneticModel::print_process(int generation ) {
  int i;   // �̃C���f�b�N�X
  int j;   // ��`�q���C���f�b�N�X
  double max_fit, min_fit, avg_fit; // �ő�C�ŏ��C���ϓK���x
  int w_count=0;

  // �e�̂̒��g���o��
  printf("\nGeneration: %d\n", generation);
  for(i=0; i<M; i++) {
    printf("%d: ", i);
    for(j=0; j<N; j++) {
      if(individual[i].gene[j] == 0) printf("%c", ' ');
      else printf("%c", '*');
	  w_count += WeightOfPkg[j] * individual[i].gene[j]; 
	}
	printf(" : fitness:%.0f Weight:%d", individual[i].fitness,w_count);
	if(individual[i].bElite)
		printf(" Elite!");
	printf("\n");
	w_count = 0;
  }
  
  // �̏W�c�̍ő�C�ŏ��C���ϓK���x�����߂�
  max_fit = min_fit = individual[0].fitness;
  avg_fit = individual[0].fitness / M;
  for(i=1; i<M; i++) {
    if(max_fit < individual[i].fitness) max_fit = individual[i].fitness;
    if(min_fit > individual[i].fitness) min_fit = individual[i].fitness;
    avg_fit += individual[i].fitness / M;
  }
  printf("max: %.2f  min: %.2f  avg: %.2f\n", max_fit, min_fit, avg_fit);

}   // End of print_process()

// ����`prob'�̊m����1��Ԃ�
int GeneticModel::flip(double prob)
{
  double x = (double)rand() / RAND_MAX;
    
  if(x<prob) return(1);
  else return(0);
}   // End of flip()

int GeneticModel::getNumOfPkg()
{
	return NumOfPkg;
}

